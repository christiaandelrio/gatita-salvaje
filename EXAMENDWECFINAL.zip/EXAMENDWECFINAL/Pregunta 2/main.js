const iniciar = () => {
    //Inputs
    const numeroInput=document.getElementById("numero");
    //Botones
    const botonEnviar=document.getElementById("enviar");
    const botonBorrar=document.getElementById("borrar");
    const botonColor=document.getElementById("color");
    //Outputs
    const resultadoDiv=document.getElementById("resultado");
    

    //Funciones
    const calcularFibonacci = (termino) => { //Devuelve un número de fibonacci calculado a partir de un número que pasamos por parámetro
        if ( termino < 2 ) {
            return termino;  
        } else {
            return calcularFibonacci(termino - 1) + calcularFibonacci(termino - 2);
        }
    }


    const imprimirFibonacci = (evento) => {//Imprimimos los números de la serie fibonacci que sean menores que el número introducido
        evento.preventDefault();
        let confirmar=confirm("¿Desea enviar el número introducido?");
        if(confirmar){
            let numero=Number(numeroInput.value);
            if(numero==""){
                alert("El número no es válido");
                numeroInput.focus();
            } 
            if(numero <1 || numero>20){
                alert("Entrada no válida: debe estar comprendida entre 1 y 20");
                numeroInput.focus();
            } else {
                let resultado="";
                for(let i=0; i<=30; i++){
                    let fibonacci=calcularFibonacci(i);//Calculamos el número de fibonacci
                    if(fibonacci<numero){
                        resultado+=`<span> ${fibonacci} </span>`;;//Lo imprimimos
                    }
                }
                resultadoDiv.innerHTML=resultado;//Imprimimos los resultados en el div
            }
        }  
    }
        
    const borrar =() =>{ //Borramos todos los campos
        numeroInput.value="";
        resultadoDiv.innerHTML="";
        numeroInput.focus();
    }

    
   
    const parpadear = () => { //Función de parpadeo, que modifica la clase del div resultado para que visualice el correspondiente css
        resultadoDiv.className="parpadea";
    }
    
    
    const pintarNumeros = (evento) =>{ 
        evento.preventDefault();
        resultadoDiv.innerHTML="";
        let numero=Number(numeroInput.value);
        if(numero==""){
            alert("Por favor, introduzca un número");
        } 
        if(numero <1 || numero>20){
            alert("El número no es válido");
        } else {
            let colorArray=new Array();
            for(let j=0; j<10; j++){
            let randomColour= "#" + Math.floor(Math.random()*16777215).toString(16);
            colorArray[j]=randomColour;
            }
            let termino=0;
            for(let i=0; i<numero;i++){
                let fibonacci=calcularFibonacci(i);
                if(fibonacci<numero){
                    resultadoDiv.innerHTML+=`<span> ${fibonacci} </span>`;
                    const spans=document.querySelectorAll("span");
                    spans[i].style.color=colorArray[i];
                    termino++; 
                } else {
                    resultadoDiv.innerHTML+="";
                }
            }
        }   
    }

    //Listeners
    botonEnviar.addEventListener("click", imprimirFibonacci,true);
    botonBorrar.addEventListener("click", borrar, true);
    botonColor.addEventListener("click", pintarNumeros, true);
    resultadoDiv.addEventListener("click",parpadear,true);
}

window.addEventListener("load", iniciar, true);