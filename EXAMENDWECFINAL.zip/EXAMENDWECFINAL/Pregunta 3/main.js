//Definimos la función que se iniciará cada vez que se cargue la ventana
const iniciar = () =>{
    //input
    const cajaFrase=document.getElementById("frase");
    cajaFrase.value="";
    //error
    const error=document.getElementById("errorFrase");
    //divs
    const cuadrado=document.getElementById("cuadrado");
    cuadrado.innerHTML="";
    const infoCookie=document.getElementById("infoCookie");
    infoCookie.innerHTML="";
    //botones
    const botonEnviar=document.getElementById("enviar");
    const botonBorrar=document.getElementById("borrar");
    const botonGuardarCookie=document.getElementById("guardarCookie");
    const botonCargarCookie=document.getElementById("cargarCookie");
    const botonTiempo=document.getElementById("tiempo");
    //Cookie
    let cookie=window.localStorage;//Inicializamos una cookie con localStorage
    //ponemos el foco en el input
    cajaFrase.focus(); 
    
    //Funciones
    const comprobarFrase = () => { //Validación de la frase
        cajaFrase.style.color="";
        const frase=cajaFrase.value;
        let patronNombre=/[A-Za-z.;,ÑñÁáÉéÍíÓóÚú]{1,100}/;
            if(!frase.match(patronNombre)){
                error.style.display="inline";
            } else {
                error.style.display="none";
            }
    }
    
    const invertirCadena = (cad) => { //Invertir cadena
        //Usar el método split() para devolver un nuevo arreglo
        var separarCadena = cad.split(""); 
        // Usar el método reverse() para invertir el nuevo arreglo creado
        var invertirArreglo = separarCadena.reverse(); 
        //Usar el método join() para unir todos los elementos del arreglo en una cadena
        var unirArreglo = invertirArreglo.join(""); 
        //Devolver la cadena invertida
        return unirArreglo;
    }

    const mostrarCuadrado=()=>{ //Mostrar cuadrado
        cajaFrase.style.backgroundColor="grey";
        let fraseRaw=cajaFrase.value;
        let fraseT=fraseRaw.trim();//Quitamos los espacios al principio y al final de la frase
        let fraseR=fraseT.replace(/\s+/g,'');//Quitamos los espacios o los dobles espacios de la frase
        let fraseSinPuntos=fraseR.replace(/[.;,]+/g, '');//Quitamos los puntos, comas y puntos y comas
        let fraseReves=invertirCadena(fraseSinPuntos);//Invertimos la cadena
        const letras=fraseReves.split('');//Dividimos la frase en letras que guardamos en un array
        cuadrado.innerHTML = '';//Cuando se haga clic en "Enviar", se borrará el cuadrado anterior si lo hubiera
        let numero=15;
        let pos=0;//posición de las letras en el array de letras
        for (let fila = 1; fila <= numero; fila++) {
            //Pintamos el contorno de asteriscos
            for (let columna = 1; columna <= numero; columna++) {
                if ( fila    == 1 || fila    == numero ||
                     columna == 1 || columna == numero) {
                        if(pos<letras.length){
                            cuadrado.innerHTML += `<span> ${letras[pos]} </span>`;
                            let colorSpan=document.querySelectorAll("span");
                            let randomColour= "#" + Math.floor(Math.random()*16777215).toString(16);
                            colorSpan[pos].style.color=randomColour;
                            pos++; 
                        }
                } else {
                    //El interior lo pintamos vacío
                    cuadrado.innerHTML += `<span> &nbsp </span>`;
                }
            }
            //Por cada vez que se itere, saltamos una línea
            cuadrado.innerHTML += '<br>';
        }
    }

    const guardarCookie = (evento) =>{ //Guarda la frase en una cookie
        evento.preventDefault();
        let frase=cajaFrase.value;
        cookie.setItem("frase",frase);//Guardamos la frase con la key "frase"
        infoCookie.innerHTML=`<p>La última frase guardada en cookie es: ${frase}</p>`;
    }

    const cargarCookie = (evento) =>{ //Carga la frase guardada en la cookie
        evento.preventDefault();
        let frase=cookie.getItem("frase");
        if(frase != "" || frase !=null){
            infoCookie.innerHTML=`<p>La última frase guardada en cookie es: ${frase}</p>`;
        } else {
            cajaFrase.value="";
            cuadrado.innerHTML="";
            infoCookie.innerHTML="<p>No existe ninguna frase guardada</p>"
        }
    }
    
    const borrar = () => {//Si se clica en el botón de borrar, se borrarán todos los campos del formulario
        cajaFrase.style.color="";
        cajaFrase.value="";
        error.style.display="none";
        cuadrado.innerText="";
        temperatura.innerText="";
        infoCookie.innerHTML="";//Se borra el mensaje de la información de la cookie pero no la cookie
        cajaFrase.focus();
    } 

    //listeners
    cajaFrase.addEventListener('click',comprobarFrase, false);//El evento se produce cuando se cambia de campo
    botonBorrar.addEventListener('click', borrar, false); //El evento se produce cuando se clica en el botón
    botonEnviar.addEventListener('click',mostrarCuadrado, false);//El evento se produce cuando se clica en el botón
    botonGuardarCookie.addEventListener("click", guardarCookie, true);
    botonCargarCookie.addEventListener("click", cargarCookie, true);
}


//Cada vez que se cargué la ventana, se llamará a la función iniciar
window.addEventListener('load', iniciar, false);